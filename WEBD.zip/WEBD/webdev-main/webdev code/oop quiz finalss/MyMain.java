class Employee {
    protected String id;
    protected String name;
    protected double salary;

    public Employee() {
        id = "id";
        name = "name";
        salary = 25000;                     // only used when no salary is given
    }
    public Employee(String id, String name) {
        this.id = id;
        this.name = name;
        salary = 25000;                     // only used when no salary is given
    }
    public Employee(String id, String name, double salary) {
        this.id = id;
        this.name = name;
        this.salary = salary;
    }
    public void setId(String id) { this.id = id; }
    public void setName(String name) { this.name = name; }
    public void setSalary(double salary) { this.salary = salary; }
}

class Teaching extends Employee {
    protected String course;

    public Teaching() {
        super();
        course = "course";
    }
    public Teaching(String course) {
        super();
        this.course = course;
    }
    public Teaching(String id, String name, String course) {
        super(id, name);
        this.course = course;
    }
    public Teaching(String id, String name, double salary, String course) {
        super(id, name, salary);
        this.course = course;
    }
    public void setCourse(String course) { this.course = course; }
}

class Professor extends Teaching {
    protected String research;

    public Professor() {
        super();
        research = "research";
    }
    public Professor(String course) {
        super(course);
        research = "research";
    }
    public Professor(String id, String name, String course, String research) {
        super(id, name, course);
        this.research = research;
    }
    public Professor(String id, String name, double salary, String course, String research) {
        super(id, name, salary, course);
        this.research = research;
    }
    public void setResearch(String research) { this.research = research; }
}

class Lecturer extends Teaching {
    public Lecturer() {
        super();
    }
    public Lecturer(String course) {
        super(course);
    }
    public Lecturer(String id, String name, String course) {
        super(id, name, course);
    }
    public Lecturer(String id, String name, double salary, String course) {
        super(id, name, salary, course);
    }
}

class Print {
    public void print(Lecturer l) {
        System.out.println(l.id);
        System.out.println(l.name);
        System.out.println(l.salary);
        System.out.println(l.course);
    }
    public void print(Professor p) {
        System.out.println(p.id);
        System.out.println(p.name);
        System.out.println(p.salary);
        System.out.println(p.course + "," + p.research);
    }
}

public class MyMain {
    public static void main(String[] args) {
        Print p = new Print();
        Lecturer lec1 = new Lecturer();
        Lecturer lec2 = new Lecturer("DAA");
        Lecturer lec3 = new Lecturer();
        Professor prof1 = new Professor();
        Professor prof2 = new Professor("System");
        Professor prof3 = new Professor();

        p.print(lec1);

        lec2.setId("1234");
        p.print(lec2);

        prof2.setId("1234");
        prof2.setName("Mr.Prof2");
        prof2.setResearch("blablabl");
        p.print(prof2);

        p.print(prof3);
    }
}