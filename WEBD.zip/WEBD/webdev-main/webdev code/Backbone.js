const LAB_ROOMS = ['C411', 'C412', 'C413', 'C414', 'C415', 'R421', 'R422', 'L501', 'R501'];

const PERIPHERALS = [
  { id: 'monitor', name: 'Monitor', iconKey: 'monitor' },
  { id: 'system_unit', name: 'System Unit', iconKey: 'system_unit' },
  { id: 'ups', name: 'Uninterrupted Power Supply (UPS)', iconKey: 'ups' },
  { id: 'keyboard', name: 'Keyboard', iconKey: 'keyboard' },
  { id: 'mouse', name: 'Mouse', iconKey: 'mouse' },
  { id: 'mousepad', name: 'Mousepad', iconKey: 'mousepad' }
];

const PERIPHERAL_ISSUES = {
  monitor: ['No display / No power', 'Flickering screen', 'Dead pixels / lines', 'Damaged VGA/HDMI cable', 'Loose power socket'],
  system_unit: ['Will not boot/power up', 'Unusual fan noise / Overheating', 'Missing RAM or front panel loose', 'Blue Screen of Death (BSOD)', 'USB ports non-responsive'],
  ups: ['Continuous alarm beep', 'Battery does not charge', 'Power cuts out abruptly', 'Burnt smell / hot chassis'],
  keyboard: ['Sticky or missing keys', 'Broken USB connector', 'Unresponsive keys (letters/spacebar)', 'Damaged elevation legs'],
  mouse: ['Left/Right click not registering', 'Scroll wheel skipping', 'Optical sensor erratic/dead', 'Frayed cable wire'],
  mousepad: ['Heavy stains/dirt', 'Torn / peeling edges', 'Surface uneven/friction issue', 'Missing from desk']
};

const ICONS = {
  monitor: `<svg viewBox="0 0 24 24"><rect x="3" y="3" width="18" height="12" rx="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="15" x2="12" y2="21"/></svg>`,
  system_unit: `<svg viewBox="0 0 24 24"><rect x="5" y="2" width="14" height="20" rx="1"/><line x1="8" y1="6" x2="16" y2="6"/><line x1="8" y1="9" x2="16" y2="9"/><circle cx="12" cy="16" r="2"/></svg>`,
  ups: `<svg viewBox="0 0 24 24"><rect x="5" y="3" width="14" height="18" rx="2"/><polygon points="13 7 9 13 14 13 11 19 16 12 12 12 13 7"/></svg>`,
  keyboard: `<svg viewBox="0 0 24 24"><rect x="2" y="5" width="20" height="14" rx="2"/><line x1="5" y1="9" x2="7" y2="9"/><line x1="9" y1="9" x2="11" y2="9"/><line x1="13" y1="9" x2="15" y2="9"/><line x1="17" y1="9" x2="19" y2="9"/><line x1="7" y1="15" x2="17" y2="15"/></svg>`,
  mouse: `<svg viewBox="0 0 24 24"><rect x="6" y="3" width="12" height="18" rx="6"/><line x1="12" y1="3" x2="12" y2="9"/><path d="M12 21 C12 23, 10 24, 8 24"/></svg>`,
  mousepad: `<svg viewBox="0 0 24 24"><path d="M4 4 h12 l4 4 v12 h-16 z"/><line x1="16" y1="4" x2="16" y2="8"/><line x1="16" y1="8" x2="20" y2="8"/></svg>`
};

const state = {
  currentUserType: null,
  studentDetails: {
    studentNo: '2024101234',
    studentName: 'Palad, Franzen R.',
    section: 'BSIT-2A',
    evalDate: new Date().toISOString().split('T')[0],
    classSchedule: '10:30 AM - 1:30 PM',
    instructorName: 'John Cedric G. Asprer'
  },
  selectedRoom: null,
  selectedPc: null,
  activePeripheralId: 'monitor',
  currentRating: 5,

  currentPcEvaluations: {},

  submittedRecords: [
    {
      id: 'REC-001',
      room: 'C414',
      pcNo: 3,
      status: 'unusable',
      issuesSummary: 'Dead display / Loose cable',
      affectedDevices: 'Monitor, System Unit',
      timestamp: '09/08/2026, 11:45 AM',
      studentNo: '2023104512',
      studentName: 'Santos, Rhein Justin',
      evaluations: {}
    },
    {
      id: 'REC-002',
      room: 'R421',
      pcNo: 7,
      status: 'semi',
      issuesSummary: 'Sticky Keys',
      affectedDevices: 'Keyboard',
      timestamp: '09/08/2026, 11:40 AM',
      studentNo: '2023108920',
      studentName: 'Tolentino, Kurt Hans',
      evaluations: {}
    },
    {
      id: 'REC-003',
      room: 'C411',
      pcNo: 1,
      status: 'functional',
      issuesSummary: 'None',
      affectedDevices: 'None',
      timestamp: '09/08/2026, 11:32 AM',
      studentNo: '2024100119',
      studentName: 'Sapasap, Phoemela',
      evaluations: {}
    }
  ]
};

const DB_KEY = 'equicheck_db_v1';
state.draftKey = null;

function saveDB() {
  try {
    localStorage.setItem(DB_KEY, JSON.stringify({
      studentDetails: state.studentDetails,
      submittedRecords: state.submittedRecords,
      selectedRoom: state.selectedRoom,
      selectedPc: state.selectedPc,
      activePeripheralId: state.activePeripheralId,
      currentPcEvaluations: state.currentPcEvaluations,
      draftKey: state.draftKey
    }));
  } catch (err) {
    console.warn('EquiCheck: could not save data', err);
  }
}

function loadDB() {
  try {
    const raw = localStorage.getItem(DB_KEY);
    if (!raw) return;
    const saved = JSON.parse(raw);
    if (saved.studentDetails) state.studentDetails = { ...state.studentDetails, ...saved.studentDetails };
    if (Array.isArray(saved.submittedRecords)) state.submittedRecords = saved.submittedRecords;
    if (saved.selectedRoom) state.selectedRoom = saved.selectedRoom;
    if (saved.selectedPc) state.selectedPc = saved.selectedPc;
    if (saved.activePeripheralId) state.activePeripheralId = saved.activePeripheralId;
    if (saved.currentPcEvaluations) state.currentPcEvaluations = saved.currentPcEvaluations;
    if (saved.draftKey) state.draftKey = saved.draftKey;
  } catch (err) {
    console.warn('EquiCheck: could not load saved data', err);
  }
}

loadDB();

const views = {
  splash: document.getElementById('view-splash'),
  evaluatorDetails: document.getElementById('view-evaluator-details'),
  roomSelection: document.getElementById('view-room-selection'),
  pcSelection: document.getElementById('view-pc-selection'),
  peripheralSelection: document.getElementById('view-peripheral-selection'),
  conditionForm: document.getElementById('view-condition-form'),
  reportSummary: document.getElementById('view-report-summary'),
  instructorLogin: document.getElementById('view-instructor-login'),
  instructorDashboard: document.getElementById('view-instructor-dashboard')
};

const navBackBtn = document.getElementById('globalBackBtn');
let viewHistory = ['view-splash'];

function navigateTo(viewId) {
  Object.keys(views).forEach(key => views[key].classList.remove('active'));
  if (views[viewId]) {
    views[viewId].classList.add('active');
  } else {
    document.getElementById(viewId)?.classList.add('active');
  }

  if (viewHistory[viewHistory.length - 1] !== viewId) {
    viewHistory.push(viewId);
  }

  navBackBtn.style.visibility = (viewId === 'view-splash' || viewId === 'view-instructor-dashboard') ? 'hidden' : 'visible';
}

function goBack() {
  if (viewHistory.length > 1) {
    viewHistory.pop();
    const prevView = viewHistory[viewHistory.length - 1];
    Object.keys(views).forEach(key => views[key].classList.remove('active'));
    document.getElementById(prevView)?.classList.add('active');
    navBackBtn.style.visibility = (prevView === 'view-splash' || prevView === 'view-instructor-dashboard') ? 'hidden' : 'visible';
  }
}

document.addEventListener('DOMContentLoaded', () => {
  initEventListeners();
  renderRooms();
  renderSeatsMatrix();
  if (Object.keys(state.currentPcEvaluations).length === 0) resetEvaluationsData();
  renderPeripheralsHub();
});

function initEventListeners() {
  navBackBtn.addEventListener('click', goBack);

  document.getElementById('btnGoStudent').addEventListener('click', () => {
    state.currentUserType = 'student';
    document.getElementById('studentNo').value = state.studentDetails.studentNo;
    document.getElementById('studentName').value = state.studentDetails.studentName;
    document.getElementById('section').value = state.studentDetails.section;
    document.getElementById('evalDate').value = state.studentDetails.evalDate;
    document.getElementById('classSchedule').value = state.studentDetails.classSchedule;
    document.getElementById('instructorName').value = state.studentDetails.instructorName;
    navigateTo('view-evaluator-details');
  });

  document.getElementById('btnGoInstructor').addEventListener('click', () => {
    state.currentUserType = 'instructor';
    navigateTo('view-instructor-login');
  });

  document.getElementById('formEvaluatorDetails').addEventListener('submit', (e) => {
    e.preventDefault();
    state.studentDetails = {
      studentNo: document.getElementById('studentNo').value,
      studentName: document.getElementById('studentName').value,
      section: document.getElementById('section').value,
      evalDate: document.getElementById('evalDate').value,
      classSchedule: document.getElementById('classSchedule').value,
      instructorName: document.getElementById('instructorName').value
    };
    saveDB();
    navigateTo('view-room-selection');
  });

  document.getElementById('formEvaluatorDetails').addEventListener('input', () => {
    state.studentDetails = {
      studentNo: document.getElementById('studentNo').value,
      studentName: document.getElementById('studentName').value,
      section: document.getElementById('section').value,
      evalDate: document.getElementById('evalDate').value,
      classSchedule: document.getElementById('classSchedule').value,
      instructorName: document.getElementById('instructorName').value
    };
    saveDB();
  });

  document.getElementById('btnSavePeripheral').addEventListener('click', saveCurrentPeripheralEvaluation);
  document.getElementById('btnResetPeripheral').addEventListener('click', resetCurrentPeripheralForm);

  document.getElementById('btnFinishInspection').addEventListener('click', populateAndGoToSummary);
  document.getElementById('btnReviewAllFromForm').addEventListener('click', populateAndGoToSummary);
  document.getElementById('btnBackToHub').addEventListener('click', () => navigateTo('view-peripheral-selection'));

  document.getElementById('pledgeCheckbox').addEventListener('change', (e) => {
    document.getElementById('btnSubmitFinalReport').disabled = !e.target.checked;
  });

  document.getElementById('btnEditEvaluation').addEventListener('click', () => {
    navigateTo('view-evaluator-details');
  });

  document.getElementById('btnSubmitFinalReport').addEventListener('click', submitFinalReport);

  document.getElementById('formInstructorLogin').addEventListener('submit', (e) => {
    e.preventDefault();
    const email = document.getElementById('loginEmail').value;
    const pass = document.getElementById('loginPassword').value;
    if ((email === 'admin@tsu.edu.ph' && pass === 'admin123') || (email && pass)) {
      document.getElementById('dashGreeting').innerText = `GOOD DAY, ${email.split('@')[0].toUpperCase()}!`;
      updateDashboardData();
      navigateTo('view-instructor-dashboard');
    } else {
      alert('Invalid instructor credentials.');
    }
  });

  document.getElementById('btnDashLogout').addEventListener('click', () => {
    navigateTo('view-splash');
  });

  document.getElementById('btnDashAccount').addEventListener('click', () => {
    alert('Instructor Account Profile: John Cedric G. Asprer\nCollege of Computer Studies (TSU-CCS)\nStatus: Authenticated');
  });

  document.getElementById('dashRoomFilterList').addEventListener('click', (e) => {
    if (e.target.tagName === 'LI') {
      document.querySelectorAll('#dashRoomFilterList li').forEach(li => li.classList.remove('active'));
      e.target.classList.add('active');
      filterDashboardByRoom(e.target.dataset.room);
    }
  });

  document.getElementById('btnExportData').addEventListener('click', exportReportsToJson);

  document.getElementById('btnCloseModal').addEventListener('click', () => {
    document.getElementById('reportDetailModal').classList.remove('active');
  });

  document.querySelectorAll('#starRatingContainer .star').forEach(star => {
    star.addEventListener('click', () => {
      const val = parseInt(star.dataset.value);
      setStarRating(val);
    });
  });

  document.querySelectorAll('input[name="availability"]').forEach(radio => {
    radio.addEventListener('change', (e) => {
      const isAvail = e.target.value === 'Available';
      document.getElementById('ratingBlock').style.opacity = isAvail ? '1' : '0.35';
      document.getElementById('issuesBlock').style.opacity = isAvail ? '1' : '0.35';
    });
  });
}

function resetEvaluationsData() {
  state.currentPcEvaluations = {};
  PERIPHERALS.forEach(p => {
    state.currentPcEvaluations[p.id] = {
      availability: 'Available',
      conditionRating: 5,
      issues: ['None'],
      customIssue: '',
      isCompleted: false
    };
  });
}

function renderRooms() {
  const container = document.getElementById('roomGridContainer');
  container.innerHTML = '';
  LAB_ROOMS.forEach(room => {
    const card = document.createElement('div');
    card.className = 'room-card';
    card.innerText = room;
    card.addEventListener('click', () => {
      state.selectedRoom = room;
      document.getElementById('pcSelectionHeading').innerText = `ROOM ${room}: SELECT YOUR PC WORKSPACE`;
      renderSeatsMatrix();
      navigateTo('view-pc-selection');
    });
    container.appendChild(card);
  });
}

function renderSeatsMatrix() {
  const matrix = document.getElementById('seatsMatrixContainer');
  matrix.innerHTML = '';

  for (let i = 1; i <= 32; i++) {
    const seatBtn = document.createElement('button');
    seatBtn.type = 'button';
    seatBtn.className = 'seat-btn';
    seatBtn.innerText = i < 10 ? `0${i}` : `${i}`;

    const existing = state.submittedRecords.find(r => r.room === state.selectedRoom && r.pcNo === i);
    if (existing) {
      if (existing.status === 'unusable') seatBtn.classList.add('status-unusable');
      else if (existing.status === 'semi') seatBtn.classList.add('status-semi');
      else if (existing.status === 'functional') seatBtn.classList.add('status-functional');
    }

    seatBtn.addEventListener('click', () => {
      state.selectedPc = i;
      const draftKey = `${state.selectedRoom}-${i}`;
      if (state.draftKey !== draftKey) {
        resetEvaluationsData();
        state.draftKey = draftKey;
      }
      saveDB();
      document.getElementById('peripheralHubTitle').innerText = `${state.selectedRoom} &bull; PC #${seatBtn.innerText}: SELECT A PERIPHERAL TO REPORT`;
      renderPeripheralsHub();
      navigateTo('view-peripheral-selection');
    });

    matrix.appendChild(seatBtn);
  }
}

function renderPeripheralsHub() {
  const hub = document.getElementById('peripheralsHubGrid');
  hub.innerHTML = '';

  PERIPHERALS.forEach(item => {
    const evalData = state.currentPcEvaluations[item.id];
    const box = document.createElement('div');
    box.className = `peripheral-box ${evalData?.isCompleted ? 'completed' : ''}`;

    box.innerHTML = `
      <div class="peripheral-svg-wrap">${ICONS[item.iconKey]}</div>
      <h4>${item.name}</h4>
      <span class="status-tag">${evalData?.isCompleted ? '&check; Checked' : 'Pending Check'}</span>
    `;

    box.addEventListener('click', () => {
      openConditionFormForPeripheral(item.id);
    });

    hub.appendChild(box);
  });
}

function openConditionFormForPeripheral(peripheralId) {
  state.activePeripheralId = peripheralId;
  const pConfig = PERIPHERALS.find(p => p.id === peripheralId);
  const data = state.currentPcEvaluations[peripheralId];

  document.getElementById('evalCurrentPcBadge').innerText = `PC #${state.selectedPc < 10 ? '0' : ''}${state.selectedPc}`;
  document.getElementById('evalCurrentPeripheralName').innerText = pConfig.name.toUpperCase();
  document.getElementById('evalIconPreview').innerHTML = ICONS[pConfig.iconKey];

  const radio = document.querySelector(`input[name="availability"][value="${data.availability}"]`);
  if (radio) radio.checked = true;

  setStarRating(data.conditionRating || 5);

  const issuesListContainer = document.getElementById('issuesChecklistContainer');
  issuesListContainer.innerHTML = '';

  const noneLabel = document.createElement('label');
  noneLabel.innerHTML = `<input type="checkbox" value="None" ${data.issues.includes('None') ? 'checked' : ''}> None (No issue)`;
  issuesListContainer.appendChild(noneLabel);

  (PERIPHERAL_ISSUES[peripheralId] || []).forEach(issue => {
    const lbl = document.createElement('label');
    const checked = data.issues.includes(issue) ? 'checked' : '';
    lbl.innerHTML = `<input type="checkbox" value="${issue}" ${checked}> ${issue}`;
    issuesListContainer.appendChild(lbl);
  });

  issuesListContainer.querySelectorAll('input').forEach(chk => {
    chk.addEventListener('change', (e) => {
      if (e.target.value === 'None' && e.target.checked) {
        issuesListContainer.querySelectorAll('input').forEach(other => {
          if (other.value !== 'None') other.checked = false;
        });
      } else if (e.target.value !== 'None' && e.target.checked) {
        const noneChk = issuesListContainer.querySelector('input[value="None"]');
        if (noneChk) noneChk.checked = false;
      }
    });
  });

  document.getElementById('customIssueInput').value = data.customIssue || '';

  renderInlineOverviewTable();
  navigateTo('view-condition-form');
}

function setStarRating(rating) {
  state.currentRating = rating;
  const stars = document.querySelectorAll('#starRatingContainer .star');
  stars.forEach(s => {
    const sVal = parseInt(s.dataset.value);
    s.classList.toggle('active', sVal <= rating);
  });

  const ratingDesc = {
    1: '1 / 5 - Dire / Broken',
    2: '2 / 5 - Poor Condition',
    3: '3 / 5 - Fair / Usable',
    4: '4 / 5 - Good Condition',
    5: '5 / 5 - Excellent'
  };
  document.getElementById('ratingLabel').innerText = ratingDesc[rating] || `${rating} / 5`;
}

function saveCurrentPeripheralEvaluation() {
  const selectedAvail = document.querySelector('input[name="availability"]:checked')?.value || 'Available';

  const checkedBoxes = Array.from(document.querySelectorAll('#issuesChecklistContainer input:checked')).map(c => c.value);
  const custom = document.getElementById('customIssueInput').value.trim();

  state.currentPcEvaluations[state.activePeripheralId] = {
    availability: selectedAvail,
    conditionRating: selectedAvail === 'Available' ? state.currentRating : null,
    issues: checkedBoxes.length > 0 ? checkedBoxes : ['None'],
    customIssue: custom,
    isCompleted: true
  };

  saveDB();
  renderInlineOverviewTable();
  renderPeripheralsHub();
  alert(`${PERIPHERALS.find(p => p.id === state.activePeripheralId).name} assessment saved!`);
}

function resetCurrentPeripheralForm() {
  state.currentPcEvaluations[state.activePeripheralId] = {
    availability: 'Available',
    conditionRating: 5,
    issues: ['None'],
    customIssue: '',
    isCompleted: false
  };
  saveDB();
  openConditionFormForPeripheral(state.activePeripheralId);
}

function renderInlineOverviewTable() {
  const tbody = document.getElementById('inlineOverviewTableBody');
  tbody.innerHTML = '';

  PERIPHERALS.forEach(p => {
    const item = state.currentPcEvaluations[p.id];
    const tr = document.createElement('tr');

    let issuesStr = item.issues.filter(i => i !== 'None').join(', ');
    if (item.customIssue) issuesStr += (issuesStr ? `, ` : '') + item.customIssue;
    if (!issuesStr) issuesStr = item.isCompleted ? 'None' : '-';

    const isPresent = item.availability === 'Available';
    const conditionText = isPresent ? (item.isCompleted ? `${item.conditionRating} ★` : '-') : '';
    const issuesText = isPresent ? issuesStr : '';

    tr.innerHTML = `
      <td title="Click to edit" style="cursor:pointer;" class="clickable-row">
        <span class="table-icon-mini">${ICONS[p.iconKey]}</span> ${p.name}
      </td>
      <td>${item.availability || 'Available'}</td>
      <td>${conditionText}</td>
      <td>${issuesText}</td>
    `;

    tr.querySelector('.clickable-row').addEventListener('click', () => {
      openConditionFormForPeripheral(p.id);
    });

    tbody.appendChild(tr);
  });
}

function populateAndGoToSummary() {
  const tbody = document.getElementById('finalSummaryTableBody');
  tbody.innerHTML = '';

  PERIPHERALS.forEach(p => {
    const item = state.currentPcEvaluations[p.id];
    const isPresent = item.availability === 'Available';
    let issuesStr = item.issues.filter(i => i !== 'None').join(', ');
    if (item.customIssue) issuesStr += (issuesStr ? `, ` : '') + item.customIssue;
    if (!issuesStr) issuesStr = 'None';

    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td><span class="table-icon-mini">${ICONS[p.iconKey]}</span> ${p.name}</td>
      <td>${item.availability}</td>
      <td>${isPresent ? `${item.conditionRating || 5} ★` : '-'}</td>
      <td>${isPresent ? issuesStr : 'Missing / Not provided'}</td>
    `;
    tbody.appendChild(tr);
  });

  document.getElementById('summaryMetaDisplay').innerHTML = `
    <div><strong>Student Number:</strong> ${state.studentDetails.studentNo}</div>
    <div><strong>Student Name:</strong> ${state.studentDetails.studentName}</div>
    <div><strong>Section:</strong> ${state.studentDetails.section}</div>
    <div><strong>Assigned Workspace:</strong> Room ${state.selectedRoom} - PC #${state.selectedPc}</div>
    <div><strong>Date:</strong> ${state.studentDetails.evalDate}</div>
    <div><strong>Course Schedule:</strong> ${state.studentDetails.classSchedule}</div>
    <div><strong>Subject Instructor:</strong> ${state.studentDetails.instructorName}</div>
  `;

  document.getElementById('pledgeCheckbox').checked = false;
  document.getElementById('btnSubmitFinalReport').disabled = true;

  navigateTo('view-report-summary');
}

function submitFinalReport() {
  let redFlag = false;
  let yellowFlag = false;
  let flaggedIssuesList = [];
  let affectedList = [];

  PERIPHERALS.forEach(p => {
    const item = state.currentPcEvaluations[p.id];
    const hasIssues = item.issues.some(i => i !== 'None') || Boolean(item.customIssue);
    const isMissing = item.availability !== 'Available';

    if (item.conditionRating <= 2 || (isMissing && ['monitor', 'system_unit'].includes(p.id))) {
      redFlag = true;
      affectedList.push(p.name);
    } else if (item.conditionRating === 3 || hasIssues || isMissing) {
      yellowFlag = true;
      affectedList.push(p.name);
    }

    if (hasIssues) {
      flaggedIssuesList.push(...item.issues.filter(i => i !== 'None'));
      if (item.customIssue) flaggedIssuesList.push(item.customIssue);
    }
  });

  const finalStatus = redFlag ? 'unusable' : (yellowFlag ? 'semi' : 'functional');

  const now = new Date();
  const timeFormatted = `${now.toLocaleDateString()}, ${now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;

  const newRecord = {
    id: `REC-${Date.now().toString().slice(-4)}`,
    room: state.selectedRoom,
    pcNo: state.selectedPc,
    status: finalStatus,
    issuesSummary: flaggedIssuesList.length > 0 ? flaggedIssuesList.slice(0, 3).join(', ') : 'None',
    affectedDevices: affectedList.length > 0 ? affectedList.join(', ') : 'None',
    timestamp: timeFormatted,
    studentNo: state.studentDetails.studentNo,
    studentName: state.studentDetails.studentName,
    evaluations: JSON.parse(JSON.stringify(state.currentPcEvaluations))
  };

  state.submittedRecords.unshift(newRecord);

  state.draftKey = null;
  resetEvaluationsData();
  saveDB();

  alert(`Report for Room ${state.selectedRoom} - PC #${state.selectedPc} submitted successfully! Status: ${finalStatus.toUpperCase()}`);

  navigateTo('view-splash');
}

function updateDashboardData(roomFilter = 'ALL') {
  const filtered = roomFilter === 'ALL'
    ? state.submittedRecords
    : state.submittedRecords.filter(r => r.room === roomFilter);

  const unusableCount = filtered.filter(r => r.status === 'unusable').length;
  const semiCount = filtered.filter(r => r.status === 'semi').length;
  const functionalCount = filtered.filter(r => r.status === 'functional').length;

  document.getElementById('countUnusable').innerText = unusableCount;
  document.getElementById('countSemiWorking').innerText = semiCount;
  document.getElementById('countFunctional').innerText = functionalCount;
  document.getElementById('countTotalReports').innerText = filtered.length;

  const tbody = document.getElementById('dashboardReportTableBody');
  tbody.innerHTML = '';

  if (filtered.length === 0) {
    tbody.innerHTML = `<tr><td colspan="8" style="text-align:center; padding:1.5rem; color:var(--text-muted);">No logs registered for room ${roomFilter}.</td></tr>`;
    return;
  }

  filtered.forEach(rec => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td><span class="badge-status ${rec.status === 'unusable' ? 'red' : (rec.status === 'semi' ? 'yellow' : 'green')}">${rec.status.toUpperCase()}</span></td>
      <td>${rec.room}</td>
      <td>${rec.pcNo}</td>
      <td>${rec.issuesSummary}</td>
      <td>${rec.affectedDevices}</td>
      <td>${rec.timestamp}</td>
      <td>${rec.studentNo}</td>
      <td><button class="btn btn-secondary btn-sm btn-view-report" data-id="${rec.id}">VIEW</button></td>
    `;

    tr.querySelector('.btn-view-report').addEventListener('click', () => {
      openReportDetailsModal(rec);
    });

    tbody.appendChild(tr);
  });
}

function filterDashboardByRoom(room) {
  updateDashboardData(room);
}

function openReportDetailsModal(record) {
  const modal = document.getElementById('reportDetailModal');
  const title = document.getElementById('modalTitle');
  const body = document.getElementById('modalBody');

  title.innerText = `Full Inspection Log: ${record.room} - PC #${record.pcNo}`;

  let evalRows = '';
  if (record.evaluations) {
    Object.keys(record.evaluations).forEach(k => {
      const e = record.evaluations[k];
      const pName = PERIPHERALS.find(p => p.id === k)?.name || k;
      evalRows += `
        <tr>
          <td><strong>${pName}</strong></td>
          <td>${e.availability}</td>
          <td>${e.conditionRating ? e.conditionRating + ' ★' : '-'}</td>
          <td>${e.issues.join(', ')} ${e.customIssue ? `(${e.customIssue})` : ''}</td>
        </tr>
      `;
    });
  }

  body.innerHTML = `
    <div style="margin-bottom:1rem; font-size:0.9rem; line-height:1.6;">
      <div><strong>Evaluator:</strong> ${record.studentName} (${record.studentNo})</div>
      <div><strong>Timestamp:</strong> ${record.timestamp}</div>
      <div><strong>Computed Status:</strong> <span class="badge-status ${record.status === 'unusable' ? 'red' : (record.status === 'semi' ? 'yellow' : 'green')}">${record.status.toUpperCase()}</span></div>
    </div>
    <table class="retro-table">
      <thead>
        <tr><th>Peripheral</th><th>Availability</th><th>Condition</th><th>Issues</th></tr>
      </thead>
      <tbody>
        ${evalRows || `<tr><td colspan="4">Detailed component snapshot unavailable for seed log.</td></tr>`}
      </tbody>
    </table>
  `;

  modal.classList.add('active');
}

function exportReportsToJson() {
  const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(state.submittedRecords, null, 2));
  const downloadAnchor = document.createElement('a');
  downloadAnchor.setAttribute("href", dataStr);
  downloadAnchor.setAttribute("download", `EquiCheck_Report_${new Date().toISOString().split('T')[0]}.json`);
  document.body.appendChild(downloadAnchor);
  downloadAnchor.click();
  downloadAnchor.remove();
}